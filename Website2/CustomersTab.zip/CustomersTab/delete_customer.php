<?php
require_once '/Applications/XAMPP/htdocs/Website2/Functions/connect.php';

// Check if the CustomerID is provided in the URL query string
if(isset($_GET['CustomerID'])) {
    $CustomerID = $_GET['CustomerID'];

    // Prepare the DELETE SQL statement
    $sql = "DELETE FROM Customers WHERE CustomerID = :CustomerID";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':CustomerID', $CustomerID, PDO::PARAM_INT);

    // Execute the prepared statement
    if($stmt->execute()) {
        echo "Customer deleted successfully";
        // Redirect to another page after deletion (e.g., customer list)
        header('Location: /Website2/admin/customers.php');
        exit;
    } else {
        echo "Error deleting customer";
    }
} else {
    // If CustomerID isn't set in the query string, redirect or handle the error
    echo "No CustomerID provided";
}
?>
