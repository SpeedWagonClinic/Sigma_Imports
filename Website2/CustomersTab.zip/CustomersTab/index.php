<?php
include '/Applications/XAMPP/htdocs/Website2/Functions/connect.php'; // connection to database
?>
<!doctype html>
<html lang="en">
  <head>
  	<title>Customer Information</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="css/style.css">

	</head>
	<body>
	<section class="ftco-section">
      <div class="container">
      

        <div class="row">
          <div class="col-md-12">
            <div class="table-wrap">
              <table class="table">
                <thead class="thead-dark">
                  <tr>
                    <th>CustomerID</th>
                    <th>Name</th>
                    <th>Surname</th>
                    <th>Email</th>
                    <th>Phone Number</th>
					<th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $sql = "SELECT * FROM Customers"; 
                  $stmt = $pdo->query($sql);

                  if ($stmt->rowCount() > 0) {
					while ($row = $stmt->fetch()) {
						echo "<tr class='alert' role='alert'>";
						echo "<th scope='row'>" . $row["CustomerID"] . "</th>";
						echo "<td>" . $row["Name"] . "</td>";
						echo "<td>" . $row["Surname"] . "</td>";
						echo "<td>" . $row["Email"] . "</td>";
						echo "<td>" . $row["PhoneNum"] . "</td>";
						echo "<td>" . $row["date"] . "</td>";
						
						echo "<td><a href='javascript:void(0);' class='close' onclick='deleteCustomer(" . $row["CustomerID"] . ")'><span aria-hidden='true'><i class='fa fa-close'></i></span></a></td>";
						echo "</tr>";
					}
				} else {
					echo "<tr><td colspan='6'>No records found.</td></tr>";
				}
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
	<a href="/Website2/admin.php" style="display: inline-block;
          width: auto;
          background-color: #ffffff;
          color: #080710;
          padding: 15px 20px;
          font-size: 18px;
		  align-items: center;
          font-weight: 600;
          border-radius: 5px;
          cursor: pointer;
          margin-top: 20px;
          text-decoration: none;">Admin Menu</a>

	<script src="js/jquery.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/main.js"></script>
	<script>
		function deleteCustomer(CustomerID) {
			if(confirm('Are you sure you want to delete this customer?')) {
				$.ajax({
					url: 'delete_customer.php',
					type: 'GET',
					data: {CustomerID: CustomerID},
					success: function(response) {
						alert(response);
						window.location.reload(); // Reloads the page
					},
					error: function() {
						alert('Error deleting customer');
					}
				});
			}
		}
    </script>

	</body>
</html>

